import React from "react";

export default function(){
    return(
        <div className="border d-flex bg-danger">
            <div className="p-2 text-white fs-5 border">w</div>
            <div className="p-2 text-white fs-5">AT-B-31</div>
        </div>
    )
}