import React from "react";

export default function ReportTable(){
    return(
        <div className="mt-2">
            <h1 className="fs-5 bg-light">Daintree residence</h1>
            <table className="w-100">
                <tr>
                    <td>Azwan Raheem</td>
                    <td>22:25</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                    <td>0</td>
                </tr>
            </table>
        </div>
    )
}